export const JWT_EXPIRATION='1h'

export const JWT_SECRET = 'Backend'